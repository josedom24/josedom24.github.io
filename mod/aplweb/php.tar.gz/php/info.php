<? echo phpinfo();?>
