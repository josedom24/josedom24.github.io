<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8" />
	<meta name="author" content="Luka Cvrk - www.solucija.com" />
	<meta name="description" content="Site Description" />
	<meta name="keywords" content="site, keywords" />
	<meta name="robots" content="index, follow" />
	<link rel="stylesheet" type="text/css" media="screen" href="css/style.css" />
	<title>Internet Encyclopedia &minus;  Free Template by Solucija.com</title>
</head>
<body>
	<div class="wrap background">
		<div id="search">
			<form action="">
				<fieldset>
					<input type="text" class="field" value="Search Keywords" />
					<input type="submit" class="button" value="" />
				</fieldset>
			</form>
		</div>
		<ul id="menu">
			<li><a class="current" href="#">HOME</a></li>
			<li><a href="#">ARTS</a></li>
			<li><a href="#">BIOGRAPHY</a></li>
			<li><a href="#">GEOGRAPHY</a></li>
			<li><a href="#">HISTORY</a></li>
			<li><a href="#">MATHEMATICS</a></li>
			<li><a href="#">SCIENCE</a></li>
		</ul>
				
		<div id="logo">
			<h1><a href="#">Internet<br />Encyclopedia</a></h1>
			<h2 id="slogan">Hunger for Knowledge</h2>
		</div>
		
		<ul id="feature_menu">
			<li><a class="current" href="#">DID YOU KNOW...</a></li>
			<li><a href="#">ON THIS DAY</a></li>
			<li><a href="#">FEATURED CONTENT</a></li>
		</ul>
			
		<div id="feature">
			<img src="images/feature_img.gif" alt="Featured" />
			<p>Mauris magna sem, pellentesque sit amet, nonummy vel, nonummy id, velit. Mauris facilisis, quam ut semper adipiscing, magna diam laoreet ante, ac varius massa dolor sit amet augue.</p>
			<p><a class="more" href="#">&not; READ MORE</a></p>
		</div>
		
		<div class="clear"></div>
		
		<div id="left">
			<h2><a href="#">Provincias</a></h2>
			<?php

include "config.inc";

if (!$dbh=mysql_connect($mysql_host, $mysql_user, $mysql_password)) {
    echo 'Could not connect to mysql';
    exit;
}
mysql_select_db($dbname);
$q="select * from provincias";
$result= mysql_query($q);

if (!$result) {
    echo "DB Error, could not list tables\n";
    echo 'MySQL Error: ' . mysql_error();
    exit;
}
echo '<form name="prov" action="index.php" method="get">';
echo '<select name="prov">';
while ($row = mysql_fetch_row($result)) {
 
    if($_GET["prov"]==$row[1]) echo "<option selected value=$row[1]>$row[1]</option>";
	else echo "<option value=$row[1]>$row[1]</option>";
}
echo '</select>';
echo '<input type="submit" value="Enviar..."/>';
echo '</form>';

if($_GET["prov"]!="")
{

echo "<br/>".$_GET["prov"]."<br/>";


$q="select municipio from municipios,provincias where provincias.id=municipios.provincia and provincias.provincia='".$_GET["prov"]."'";
$result= mysql_query($q) or die("error");

if (!$result) {
    echo "DB Error, could not list tables\n";
    echo 'MySQL Error: ' . mysql_error();
    exit;
}
echo '<select size="10">';
while ($row = mysql_fetch_row($result)) {
echo "<option>".$row[0]."</option>";}
echo "</select>";
}
mysql_free_result($result);
?> 
			
		</div>
		
		<div id="side">
				<div class="boxtop"></div>
				<div class="box">
					<h3>POPULAR ARTICLES</h3>
					<a href="#">
					<span class="item">
						<span class="sidedate">4.5<br /><span>RATING</span></span>
						<strong>Lorem ipsum dolor sit amet</strong><br />Consectetuer adipiscing elit.
					</span>
					</a>
					<a href="#">
					<span class="item">
						<span class="sidedate">4.5<br /><span>RATING</span></span>
						<strong>Suspendisse odio orci</strong><br />Nam tortor libero, dictum vulputate.
					</span>
					</a>
					<a href="#">
					<span class="item last">
						<span class="sidedate">4.5<br /><span>RATING</span></span>
						<strong>Aliquam metus turpis luctus ac</strong><br />Suspendisse egestas fringilla odio.
					</span>
					</a>
				</div>
				<div class="boxbottom"></div>
		</div>
		<p id="ad">Suspendisse egestas fringilla odio. Donec lacinia tristique ante. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Etiam blandit ultricies nisl. Nullam dapibus, mauris id scelerisque feugiat, sapien augue porta ipsum, ut blandit tellus enim vel mauris. Praesent accumsan metus vel. </p>
	</div>
	
	<div id="promo">
		<div class="wrap">	
			<div class="col">
				<img id="featured" src="images/featured.gif" alt="Featured Image" />
			</div>
			<div class="col">
				<h2>About Solucija</h2>
				<p>Solucija offers a selection of some of the hottest web templates available. Looking for a free web template, commercial one, or an inspiration? You'll find it on <a href="http://www.solucija.com" title="Free Templates">Solucija</a>.</p>
			</div>
			<div class="col last">
				<h2>Like this template?</h2>
				<p>If you liked this template, you might like some other Free CSS Templates from <a href="http://www.solucija.com" title="Information Architecture and Web Design">Solucija</a>.</p>
			</div>
			<div id="footer">
				 <p>Copyright &copy; 2008 &minus; Internet Encyclopedia &minus; Design: Luka Cvrk, <a title="Awsome Web Templates" href="http://www.solucija.com/">Solucija</a></p>
			</div>
		</div>
	</div>
</body>
</html>
